#define GIT_BRANCH desenv
#define GIT_VERSION 1.0
#define GIT_COMMITS 0
