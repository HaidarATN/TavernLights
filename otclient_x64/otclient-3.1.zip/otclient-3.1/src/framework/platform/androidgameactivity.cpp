#ifdef ANDROID

#include <game-activity/GameActivity.cpp>
#include <game-text-input/gametextinput.cpp>
extern "C" {
  #include <game-activity/native_app_glue/android_native_app_glue.c>
}

#endif